Photo Carousel Portlet
======================

This portlet creates a photo carousel of images in a Documents and media folder. 

See a demo and more information at http://javaguru.fi/projects/photo-carousel-portlet 
